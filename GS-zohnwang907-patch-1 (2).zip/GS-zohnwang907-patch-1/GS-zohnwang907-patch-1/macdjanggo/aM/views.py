from django.shortcuts import render
from .models import Activity

def acti(request):
    # 从数据库中获取活动数据
    #get data from the database
    activities = Activity.objects.all()

    # 将数据传递给模板，并渲染模板
    # Render the template with the activities data
    return render(request, "activity.html", {'activities': activities})

