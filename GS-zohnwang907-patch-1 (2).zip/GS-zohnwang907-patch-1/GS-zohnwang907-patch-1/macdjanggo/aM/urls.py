from django.urls import path
from . import views


urlpatterns=[
    path('',views.acti,name='activity')
]
