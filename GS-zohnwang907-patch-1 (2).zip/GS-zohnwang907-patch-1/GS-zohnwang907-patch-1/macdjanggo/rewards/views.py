from django.shortcuts import render
from .models import Gift
from django.shortcuts import get_object_or_404, render


def gift_list(request):
    gifts = Gift.objects.all()
    sort_method = request.GET.get('sort')

    if sort_method == 'asc':
        gifts = gifts.order_by('points')
    elif sort_method == 'desc':
        gifts = gifts.order_by('-points')

    return render(request, 'rewards/gift_list.html', {'gifts': gifts})


def gift_detail(request, id):
    gift = get_object_or_404(Gift, pk=id)
    return render(request, 'rewards/gift_detail.html', {'gift': gift})
